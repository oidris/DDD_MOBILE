package org.fhi360.ddd.util;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MyList {
    private int image;
    private String desc;

}
