package org.fhi360.ddd;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.mind.ddd.R;

import org.fhi360.ddd.adapter.MyAdapter;
import org.fhi360.ddd.util.MyList;

import java.util.ArrayList;
import java.util.List;

public class ActivityOptions extends AppCompatActivity {
    private List<MyList> myLists;
    private MyAdapter adapter;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refil_darshbaord);
        recyclerView=findViewById(R.id.rec);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        myLists=new ArrayList<>();
        getdata();

    }


    private void getdata() {
        myLists.add(new MyList(R.drawable.ic_add,"Manual Patient List"));
        myLists.add(new MyList(R.drawable.link,"Assigned Patient List From Facility"));
        adapter=new MyAdapter(myLists,getApplicationContext());
        recyclerView.setAdapter(adapter);
    }
}
