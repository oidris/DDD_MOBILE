package org.fhi360.ddd.repositories;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import org.fhi360.ddd.domain.Facility;
import org.fhi360.ddd.domain.Patient;
import java.util.List;
@Dao
public interface FacilityRepository {

    @Insert
    void save(Facility patients);

    @Update
    void update(Facility patients);


    @Query("SELECT * FROM facility where id = :facilityId")
    Facility findOne(int facilityId);


    @Query("SELECT * FROM facility")
     List<Facility> findAll();

}
