package org.fhi360.ddd.repositories;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import org.fhi360.ddd.domain.Patient;
import java.util.List;
@Dao
public interface PatientRepository {

    @Query("SELECT * FROM patient")
    List<Patient> findByAll();

    @Query("SELECT * FROM patient where id = :id")
    Patient findOne(int id);

    @Query("SELECT * FROM patient where hospital_num = :hospitalNum")
    boolean findHospitalNum(String hospitalNum);



    //@Query("SELECT * FROM patient WHERE surname or other_names LIKE ?1")
    //List<Patient> findByName(String fullName);

    @Insert
    long save(Patient patients);

    @Update
    void update(Patient patients);

    @Query("DELETE  FROM patient where id = :id")
    void delete(int id);
}
