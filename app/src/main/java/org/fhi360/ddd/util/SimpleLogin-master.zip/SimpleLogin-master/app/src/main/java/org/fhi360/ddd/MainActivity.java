package org.fhi360.ddd;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.mind.ddd.R;

public class MainActivity extends AppCompatActivity {
    private LinearLayout newVisit,reVisit,summaryReport,synchronize;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newVisit = findViewById(R.id.newVisit);
        reVisit = findViewById(R.id.reVisit);
        summaryReport = findViewById(R.id.summaryReport);
        synchronize = findViewById(R.id.synchronize);

        newVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewVisit.class);
                startActivity(intent);
            }
        });

        reVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ActivityOptions.class);
                startActivity(intent);
            }
        });

        summaryReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

}
